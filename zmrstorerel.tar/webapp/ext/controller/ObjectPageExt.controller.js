sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel", "sap/m/MessageToast"], function(e, t, n) {
    "use strict";
    return {
        onAfterRendering: function() {
            var view = this.getView();
            
            var bankDesc = view.byId("MerStoreRel::BankDesc::Field");

            bankDesc.setEnabled(false);

            var shopDesc = view.byId("MerStoreRel::ShopDesc::Field");

            shopDesc.setEnabled(false);
        }

    }
});