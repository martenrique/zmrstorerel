sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.consum.fiori.fi.zmrstorerel.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);